%This function transforms a canonical ordering C into a star-canonical ordering

function [LI, LD, SI, SD, M] = scanonical(C) 

n=size(C,1)+1;
auxM = max(max(C));
auxm = min(min(C)); 

C(n,:) = zeros(1,n-1);
C(:,n) = zeros(n,1);
LI = C; 
LD = C;
SI = C+n.*triu(ones(n,n),1);
SD = C+n.*triu(ones(n,n),1);
M  = C;


for i=1:(n-1)
    LI(i,n) = auxM + i; 
    LD(i,n) = auxM +n-i;
    SI(i,n) = auxm+i;
    SD(i,n) = auxm+n-i;
    M(i,n)  = 2*(n-1)*i;
end

end
