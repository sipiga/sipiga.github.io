The program run in MATLAB. Upper triangular matrices represent edge-labelings in graphs which induce edge-ordered graphs. 
For i<j the value of the entry M(i,j) of a Matrix M represents the label of an edge ij of a graph G. 
We assume all labels are positive and use the label zero to represent a non-edge. 

canonical.m	Function that creates all four canonical orderings on n vertices
main.m 		Main program. It finds all needed orderings. 
path.m		Function that transform a sequence of integers into a upper triangular matrix which represent the respective edge-ordering of a path.
scanonical.m	Function that creates all twenty star-canonical orderings on n vertices
subEOgraph.m	Function that says if F is a subgraph of a given edge-ordering of the complete graph.
symm.m 		Function that symetrize an upper triangular matrix.