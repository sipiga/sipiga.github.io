


%This functions generates canonical orderings on n vertices
function [min, max, mininv, maxinv] = canonical(n)

min = zeros(n);
mininv = zeros(n);
max = zeros(n);
maxinv = zeros(n);

for i=1:(n-1)
    for j=i+1:n 
        min(i,j)= 2*n*i+j-1;
        max(i,j)= (2*n-1)*j+i;
        mininv(i,j) = (2*n+1)*i-j;
        maxinv(i,j) = 2*n*j-i+n;
    end
end

end







    