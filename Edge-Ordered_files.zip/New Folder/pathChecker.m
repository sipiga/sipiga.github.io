n=8;

[MIN, MAX, MININV, MAXINV]  = canonical(n-1);
[MIN2, MAX2, MININV2, MAXINV2]  = canonical(n);


[mLI, mLD, mSI, mSD, mM] = scanonical(MIN);
[MLI, MLD, MSI, MSD, MM] = scanonical(MAX);
[miLI, miLD, miSI, miSD, miM] = scanonical(MININV);
[MiLI, MiLD, MiSI, MiSD, MiM] = scanonical(MAXINV);

M = {   mLI, mLD, mSI, mSD, mM ;
        MLI, MLD, MSI, MSD, MM; 
        miLI, miLD, miSI, miSD, miM; 
        MiLI, MiLD, MiSI, MiSD, MiM};

PATHmSI = [6,2,3,4,0,1,5; 5,1,0,4,3,2,6; 5,2,3,4,0,1,6; 6,1,0,4,3,2,5; 6,4,3,2,0,1,5; 5,2,3,1,0,4,6; 6,4,0,1,3,2,5; 5,1,0,2,3,4,6]+1;
PATHmSD =[5,2,3,0,1,4,6; 6,0,1,4,3,2,5; 6,2,3,4,1,0,5; 5,0,1,2,3,4,6; 5,0,1,4,3,2,6; 6,4,3,2,1,0,5; 5,2,3,4,1,0,6; 6,4,1,0,3,2,5]+1;
PATHMLI = [0,6,5,2,3,4,1; 1,6,5,2,3,4,0; 1,6,5,4,3,2,0; 1,4,3,6,5,2,0; 1,4,3,2,5,6,0; 0,2,5,6,3,4,1; 0,4,3,2,5,6,1; 0,2,3,4,5,6,1]+1;
PATHMLD = [1,5,6,2,3,4,0; 1,4,3,2,6,5,0; 0,4,3,2,6,5,1; 0,2,3,4,6,5,1; 1,5,6,4,3,2,0; 1,4,3,5,6,2,0 ; 0,2,6,5,3,4,1; 0,5,6,2,3,4,1]+1;
PATHmiSI= [5,1,0,3,2,4,6; 6,4,2,3,0,1,5]+1;
PATHmiSD = [5,0,1,3,2,4,6; 6,4,2,3,1,0,5]+1;
PATHMiLI = [1,6,5,3,4,2,0; 0,2,4,3,5,6,1]+1;
PATHMiLD = [1,5,6,3,4,2,0; 0,2,4,3,6,5,1]+1;

embeddings = {};
P= {PATHmSI , PATHmSD, PATHMLI, PATHMLD, PATHmiSI, PATHmiSD, PATHMiLI, PATHMiLD};    %


for c=1:size(P,2)
    for k=1:size(P{c},1)
        PATH=path(P{c}(k,:));
        for i=1:4 
            for j=1:5
                embeddings{i,j,c,k} = subEOgraph(M{i,j},PATH);
                if (sum(subEOgraph(M{i,j},PATH)) == 0)
                    disp(['Path ' num2str(c) ',' num2str(k) ' not tileable for ' num2str(i) ',' num2str(j)])
                end
            end
        end
    end
end





    

