

%Edge-ordered graphs are represented as upper matrices.

%Given an edge-ordered graph F and an edge-ordering of Kn, the following function checks if F is a subgraph of Kn.
%G is the edge-ordering of Kn.

function [sub] = subEOgraph(G,F)

%If F is subgraph it return the embedding. If not it return zeros(n,1).

n=size(G,1); 
v=1:n;
sub=zeros(n,1);
aux=0;
quit = 0;
G=symm(G);
F=symm(F);

for P=perms(v).' %we check every possible embedding.
    aux=0;
    
    %x,y,z,w are pairs edges. We want to check that xy < zw in F implies xy < zw in G
    for x=1:(n-1)
        for y=x+1:n
            for z=1:(n-1)
                for w=z+1:n
                        quit = 0;
                        if F(P(x),P(y))~=0 && F(P(z),P(w))~=0 && ( (G(x,y)<G(z,w)) ~= (F(P(x),P(y))<F(P(z),P(w))) )
                            %Both P(x),P(y) and P(z),P(w) are edges in F and this embedding does not respect the ordering for the edges xy, zw. 
                            aux=1; %it was not a subgraph
                            quit=1; %technical variable to break all loops. 
                            break;  %break the w-loop
                        end
                end
                if quit
                    break;
                end
            end
            if quit
                break;
            end
        end
        if quit
            break;
        end
    end
    if aux == 0           %if after going all pairs of edges xy, zw it never change aux then F is edge-ordered subgraph
        sub=P;            %The function return the embedding. 
        return
    end
end
end


