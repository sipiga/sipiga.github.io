
function M=symm(A)
    M=A;

    for i=1:size(A,1)-1
        for j=i+1:size(A,1)
            M(j,i) = M(i,j);
        end
    end
end

           

