
function P=path(v)

n=length(v)+1;
P=zeros(n);
    for i=1:length(v)
        P(i,i+1)=v(i);
    end
end
