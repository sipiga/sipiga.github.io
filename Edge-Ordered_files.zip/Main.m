
%Main Program

%Fix the number of vertices
n=8;

%Create canonical orderings on n-1 vertices
[MIN, MAX, MININV, MAXINV]  = canonical(n-1);
[MIN2, MAX2, MININV2, MAXINV2]  = canonical(n);


%Create star-canonical orderings on n vertices.
[mLI, mLD, mSI, mSD, mM] = scanonical(MIN);
[MLI, MLD, MSI, MSD, MM] = scanonical(MAX);
[miLI, miLD, miSI, miSD, miM] = scanonical(MININV);
[MiLI, MiLD, MiSI, MiSD, MiM] = scanonical(MAXINV);


% M contains all 20 star-canonical orderings.
%the first cordinate from 1 to 4 caracterize the type canonical part. 
% the second coordinate from 1 to 5 caracterize the type of star-canonical
M = {   mLI, mLD, mSI, mSD, mM ; 
        MLI, MLD, MSI, MSD, MM; 
        miLI, miLD, miSI, miSD, miM; 
        MiLI, MiLD, MiSI, MiSD, MiM };

%Good paths are non-tileable paths that fail in exactly one star-canonical ordering.
%Together with the ordering for which they fail
goodpaths=zeros(1,n+1);

%these are the orderings that are needed.
orderings=zeros(4,5);

%Bad paths are non-tileable paths that fail for at least two star-canonical orderings.
%together with the pair of orderings for which they fail.
badpaths=zeros(1,n+3); 

%Counter and auxiliary variables.
gc=0; bc=0; 
quit=0;
quit1=0;
quit2=0;
i=1;
j=1;

%main loop:
%Check all canonical orderins M(i,j)
while i<5 
    j=1;
    while j<6           

        %display the ordering we are checking.
        disp(['(' num2str(i) ',' num2str(j) ')'])

        quit2=0;
        
        %check for all possible paths on n vertices (i.e. all permutations)
        for P=perms(1:(n-1)).'

            if quit2   %In case we found a path that shows this ordering is needed (see line 113)
                break
            end


            %if we already know this path is good or bad we stop
            k=1;
            quit=0;
            while k<=gc || k<=bc
            if (k<=bc) && (prod(P'==badpaths(k,1:(n-1)))>0) %check if the path is bad
                quit=1;
                break %break the k-loop
            end
            if (k<=gc) && (prod(P'==goodpaths(k,1:(n-1)))>0)  %check if the path is good
                quit=1;
                break %break the k-loop
            end 
            k=k+1;
            end
           
            if quit==0 %we try the path only if it was not good nor bad
                

                PATH=path(P); %the path not good nor bad, so we try it.
                   
                %we need to check for every two orderings whether it fails to be embeddable.
                % a,b,c,d are variable for those orderings M{a,b} and M{c,d} 
                % c,d are always i,j. We just use the variable to save the value in 'badpaths'
                a=1;
                b=1;
                c=0; %to save the orderings for which the pad path is bad.
                d=0;
                
                if (sum(subEOgraph(M{i,j},PATH)) == 0) %% If the path is not embedable in M{i,j} it is a good candidate.
                    while a<5    
                        b=1;
                        while b<6
                            if ((i~=a) || (j~=b)) && (sum(subEOgraph(M{a,b},PATH)) == 0)  %we try the other orderings, and if it is not embeddable in some other we stop
                               quit1=1;
                               c=a; d=b; %save the second ordering.
                               a=4;  b=5; %we stop trying other orderings for this (bad)path
                            end
                            b=b+1;
                        end
                        a=a+1; 
                    end
                    
                    %if the path was good:
                    if quit1==0                     % The path was embeddable in all orderings not equal to (i,j)
                        gc=gc+1;
                        goodpaths(gc,:)=[P', i ,j]; % Save the path and the ordering for which it works.
                        orderings(i,j)=1;           % Save this ordering as needed.
                        disp(['path ' num2str(P') ' works for ' num2str(i) ',' num2str(j)])
                        quit2=1;                    % We dont try more paths for this ordering i,j
                    end

                    %if the path was bad
                    if quit1==1                     
                        bc=bc+1;
                        badpaths(bc,:)=[P', i,j,c,d];  %save the path and the ordering for which it works.
                        quit1=0;                       %Restart the quit1 variable.
                    end
                end
            end  
        end
        j=j+1;
    end
    i=i+1;
end





